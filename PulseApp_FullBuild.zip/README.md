# Pulse App
This is the main repository for the Pulse emotional AI app.